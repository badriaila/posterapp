import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signin-or-signup',
  templateUrl: './signin-or-signup.component.html',
  styleUrls: ['./signin-or-signup.component.css']
})
export class SigninOrSignupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }


}
